# FPGA Bitstreams
FPGA bitstreams for mining the Nexus Hash channel are currently avaiable for Beta testing on the following devices. For access, please make a request in the Nexus mining [telegram channel](https://t.me/NexusMiners).
FPGA Board | Manufacturer | Hash Rate (MH/s) | Power Estimate (W)
---------- | ------------ | ---------------- | ------------------
FK33 | SQRL | 700 | tbd
[KCU105](https://www.xilinx.com/products/boards-and-kits/kcu105.html) | Xilinx | 188 | 34


