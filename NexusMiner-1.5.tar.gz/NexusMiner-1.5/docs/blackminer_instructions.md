# Mining Nexus with Blackminer
## Software
## Bitstream
## Pool
* `hashpool.nexus.io:50000`
* Nexus address must be a Tritium (non-legacy) address.  
* Do not put a "." or user name after the address
## Support
* [Nexus Miners](https://t.me/NexusMiners) on telegram for Nexus wallet and pool related support.
