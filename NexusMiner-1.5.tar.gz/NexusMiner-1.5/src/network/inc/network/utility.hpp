#ifndef NEXUSMINER_NETWORK_UTILITY_HPP
#define NEXUSMINER_NETWORK_UTILITY_HPP

#include <cstdlib>
#include <string>

//#ifdef _WIN32_WINNT
//#include <Iphlpapi.h>
//#include <Netioapi.h>
//#else
//#include <net/if.h>
//#endif

namespace nexusminer {
namespace network {

using Scope_id = unsigned int;

} // namespace network
} // namespace nexusminer


#endif // NEXUSMINER_NETWORK_UTILITY_HPP
